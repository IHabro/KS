from solution import Solution
from functions import Functions

# Main
if __name__ == "__main__":
    fs = ["sphere", "schwefel", "rosenbrock", "rastrigin", "griewank", "levy", "michalewicz", "zakharov", "ackley"]
    # fs[1], fs[3], fs[4], fs[5], fs[6] maji potize pri vykresleni
    # for f in fs:
    #     sol = Solution(2, -5, 5, f)
    #     sol.hill_climb(20, 10000, 1.0)

    sol = Functions(fs[5])

    for i in range(5):
        for j in range(5):
            print("([{}, {}], {})".format(i, j, sol.start([i, j])))
