import random
import numpy as np
import matplotlib.pyplot as plt

from functions import Functions


class Solution:
    def __init__(self, dimension: int, lower_bound: float, upper_bound: float, function: str):
        self.dimension = dimension
        self.lower = lower_bound  # we will use the same bounds for all parameters
        self.upper = upper_bound
        self.parms = np.zeros(self.dimension)  # solution parameters
        self.fnctn = Functions(function)
        self.f = np.inf  # objective function evaluation

    def plot(self, points: list[list[float]], best: list[float]):
        # Inicializace grafu
        fig = plt.figure()
        ax = plt.axes(projection='3d')

        corX = np.linspace(self.lower, self.upper)
        corY = np.linspace(self.lower, self.upper)
        corX, corY = np.meshgrid(corX, corY)
        corZ = self.fnctn.start([corX, corY])

        # Vykresleni plochy funkce
        surf = ax.plot_surface(corX, corY, corZ, cmap="plasma", linewidth=0, antialiased=False, alpha=0.6)

        # Pridani bodu
        if self.dimension == 2:
            for point in points:
                pointToPlot = ax.scatter(point[0], point[1], self.fnctn.start(point), c="green")

            ax.scatter(best[0], best[1], self.fnctn.start(best), c="red")

        # Vykresleni vysledku
        plt.show()

    def get_solution(self) -> list[float]:
        result = []

        for i in range(self.dimension):
            result.append(random.uniform(self.lower, self.upper))

        return result

    def get_normal_solution(self, bestSolution: list[float], sigma: float) -> list[float]:
        result = []

        for i in range(self.dimension):
            result.append(np.random.normal(bestSolution[i], sigma, 1))

        return result

    # Implementace BlindSearch algoritmu
    def blind_search(self, gens: int, points: int):
        bestSolution = self.get_solution()
        bestValue = self.fnctn.start(bestSolution)
        bestSolutions = []

        genSolutions = []
        values = []

        for g in range(gens):
            for p in range(points):
                solution = self.get_solution()
                genSolutions.append(solution)
                values.append(self.fnctn.start(solution))

            mn = min(values)

            if mn < bestValue:
                bestSolution = genSolutions[values.index(mn)]
                bestValue = mn
                bestSolutions.append(bestSolution)

        self.plot(bestSolutions, bestSolution)

    def hill_climb(self, gens: int, points: int, sigma: float):
        bestSolution = self.get_solution()
        bestValue = self.fnctn.start(bestSolution)
        bestSolutions = []

        genSolutions = []
        values = []

        for g in range(gens):
            for p in range(points):
                solution = self.get_normal_solution(bestSolution, sigma)
                genSolutions.append(solution)
                values.append(self.fnctn.start(solution))

            mn = min(values)

            if mn < bestValue:
                bestSolution = genSolutions[values.index(mn)]
                bestValue = mn
                bestSolutions.append(bestSolution)

        self.plot(bestSolutions, bestSolution)

    # Blind search starting from self.upper, self.upper
    def test_blind(self, gens: int, points: int):
        bestSolution = [self.upper, self.upper]
        bestValue = self.fnctn.start(bestSolution)
        bestSolutions = []
        bestSolutions.append(bestSolution)

        genSolutions = []
        values = []

        if gens <= 0 or points <= 0:
            return bestSolutions

        for g in range(gens):
            for p in range(points):
                solution = self.get_solution()
                genSolutions.append(solution)
                values.append(self.fnctn.start(solution))

            mn = min(values)
            bestSolutions.append(genSolutions[values.index(mn)])

            if mn < bestValue:
                bestSolution = genSolutions[values.index(mn)]
                bestValue = mn

        return bestSolutions
